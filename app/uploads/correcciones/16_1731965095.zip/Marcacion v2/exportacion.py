import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
from datetime import datetime

from fpdf import FPDF
import openpyxl

# Conexión a la base de datos
def conectar_base_datos():
    try:
        conexion = mysql.connector.connect(
            host='localhost',
            port=3308,
            database='sistemaMarcacion',
            user='root',
            password=''
        )
        return conexion
    except mysql.connector.Error as err:
        messagebox.showerror("Error de conexión", f"No se pudo conectar a la base de datos:\n{err}")
        return None

# Función para exportar datos a PDF y XLSX con filtro de año, mes y día opcional
def exportar_datos():
    # Crear una ventana para la selección de año, mes y día
    ventana_exportacion = tk.Toplevel()
    ventana_exportacion.title("Exportación de Datos")
    ventana_exportacion.geometry("400x250")

    # Frame para los filtros de año, mes y día
    frame_filtro = tk.Frame(ventana_exportacion)
    frame_filtro.pack(pady=20)

    label_anio = tk.Label(frame_filtro, text="Año:")
    label_anio.grid(row=0, column=0, padx=5)
    combo_anio = ttk.Combobox(frame_filtro, values=[str(i) for i in range(2000, datetime.now().year + 1)], state="readonly")
    combo_anio.grid(row=0, column=1, padx=5)

    label_mes = tk.Label(frame_filtro, text="Mes:")
    label_mes.grid(row=1, column=0, padx=5)
    combo_mes = ttk.Combobox(frame_filtro, values=[str(i).zfill(2) for i in range(1, 13)], state="readonly")
    combo_mes.grid(row=1, column=1, padx=5)

    label_dia = tk.Label(frame_filtro, text="Día (opcional):")
    label_dia.grid(row=2, column=0, padx=5)
    combo_dia = ttk.Combobox(frame_filtro, values=[str(i).zfill(2) for i in range(1, 32)], state="readonly")
    combo_dia.grid(row=2, column=1, padx=5)

    # Función interna para ejecutar la exportación de datos con los filtros seleccionados
    def ejecutar_exportacion():
        anio = combo_anio.get()
        mes = combo_mes.get()
        dia = combo_dia.get()

        if not anio or not mes:
            messagebox.showwarning("Advertencia", "Seleccione un año y un mes para filtrar los datos.")
            return

        conexion = conectar_base_datos()
        if conexion is None:
            return

        try:
            cursor = conexion.cursor()
            
            # Construir la consulta dinámica según los filtros seleccionados
            query = """
                SELECT b.Cedula, b.Nombre, e.fecha_entrada, e.hora_entrada, 
                       COALESCE(s.fecha_salida, 'N/A') AS fecha_salida, 
                       COALESCE(s.hora_salida, 'N/A') AS hora_salida
                FROM biometric b
                JOIN entrada e ON b.id = e.biometric_id
                LEFT JOIN salida s ON b.id = s.biometric_id AND s.entrada_id = e.id
                WHERE YEAR(e.fecha_entrada) = %s AND MONTH(e.fecha_entrada) = %s
            """
            params = [anio, mes]

            # Agregar el día al filtro si se seleccionó
            if dia:
                query += " AND DAY(e.fecha_entrada) = %s"
                params.append(dia)

            cursor.execute(query, params)
            registros = cursor.fetchall()

            if not registros:
                messagebox.showinfo("Sin datos", "No se encontraron registros de entrada y salida para el filtro seleccionado.")
                return

            # Exportar a PDF
            pdf = FPDF()
            pdf.add_page()
            pdf.set_font("Arial", size=12)
            
            pdf.cell(200, 10, txt="Reporte de Marcaciones", ln=True, align="C")
            pdf.cell(200, 10, txt=f"Año: {anio}, Mes: {mes}, Día: {dia if dia else 'Todos'}", ln=True, align="C")
            pdf.cell(200, 10, txt="Cédula - Nombre - Fecha Entrada - Hora Entrada - Fecha Salida - Hora Salida", ln=True, align="L")
            
            for row in registros:
                pdf.cell(200, 10, txt=" - ".join([str(dato) if dato is not None else "N/A" for dato in row]), ln=True, align="L")
            
            pdf.output("Reporte_Marcaciones_Filtrado.pdf")
            
            # Exportar a XLSX
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Marcaciones"
            
            # Encabezados
            ws.append(["Cédula", "Nombre", "Fecha Entrada", "Hora Entrada", "Fecha Salida", "Hora Salida"])
            
            for row in registros:
                ws.append(row)
            
            wb.save("Reporte_Marcaciones_Filtrado.xlsx")
            
            messagebox.showinfo("Exportación completa", "Datos exportados exitosamente a PDF y XLSX.")
        
        except mysql.connector.Error as err:
            messagebox.showerror("Error", f"No se pudo exportar los datos:\n{err}")
        finally:
            cursor.close()
            conexion.close()

    # Botón para ejecutar la exportación
    btn_exportar = tk.Button(ventana_exportacion, text="Exportar", command=ejecutar_exportacion)
    btn_exportar.pack(pady=10)
