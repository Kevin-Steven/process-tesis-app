import tkinter as tk
from tkinter import messagebox
import mysql.connector
from datetime import datetime, timedelta, time
import cv2
from PIL import Image, ImageTk
import exportacion  # Importar el archivo exportacion.py

# Conexión a la base de datos
def conectar_base_datos():
    try:
        conexion = mysql.connector.connect(
            host='localhost',
            port=3308,
            database='sistemaMarcacion',
            user='root',
            password=''
        )
        return conexion
    except mysql.connector.Error as err:
        messagebox.showerror("Error de conexión", f"No se pudo conectar a la base de datos:\n{err}")
        return None

# Función para buscar el usuario y mostrar el botón de toma de foto o los registros de entrada y salida
def buscar_usuario():
    cedula = entry_cedula.get()
    if not cedula:
        messagebox.showwarning("Advertencia", "Por favor, ingrese un número de cédula.")
        return

    conexion = conectar_base_datos()
    if conexion is None:
        return

    try:
        cursor = conexion.cursor()
        query = "SELECT id, Nombre FROM biometric WHERE Cedula = %s"
        cursor.execute(query, (cedula,))
        resultado = cursor.fetchone()

        if not resultado:
            messagebox.showwarning("No encontrado", "No se encontró un usuario con esa cédula.")
            return

        global biometric_id
        biometric_id, nombre = resultado
        fecha_hoy = datetime.now().date()
        
        # Verificar si ya existe una entrada hoy
        cursor.execute("SELECT hora_entrada FROM entrada WHERE biometric_id = %s AND fecha_entrada = %s", (biometric_id, fecha_hoy))
        entrada = cursor.fetchone()

        cursor.execute("SELECT hora_salida FROM salida WHERE biometric_id = %s AND fecha_salida = %s", (biometric_id, fecha_hoy))
        salida = cursor.fetchone()

        if entrada and salida:
            # Ya tiene entrada y salida registradas hoy
            hora_entrada = entrada[0]
            hora_salida = salida[0]
            messagebox.showinfo("Registro Completo", f"Ya se ha registrado tanto una entrada como una salida hoy.\n\nFecha: {fecha_hoy}\nHora de entrada: {hora_entrada}\nHora de salida: {hora_salida}")
        elif entrada:
            # Solo tiene entrada registrada, verificar si ya cumple con las 8 horas
            hora_entrada = entrada[0]

            # Intentar convertir `hora_entrada` a un objeto `time` si es un `timedelta`
            if isinstance(hora_entrada, timedelta):
                hora_entrada = (datetime.min + hora_entrada).time()

            # Verificar nuevamente que `hora_entrada` sea `time` después de la conversión
            if not isinstance(hora_entrada, time):
                messagebox.showerror("Error", "La hora de entrada no tiene el formato esperado.")
                return
            
            # Calcular el tiempo transcurrido
            tiempo_transcurrido = datetime.now() - datetime.combine(fecha_hoy, hora_entrada)
            
            if tiempo_transcurrido < timedelta(hours=8):
                # No ha cumplido con las 8 horas, mostrar tiempo restante
                tiempo_restante = timedelta(hours=8) - tiempo_transcurrido
                horas_restantes = tiempo_restante.seconds // 3600
                minutos_restantes = (tiempo_restante.seconds % 3600) // 60
                messagebox.showwarning(
                    "Horario Incompleto",
                    f"No se puede marcar la salida hasta cumplir con el horario laboral de 8 horas.\n\n"
                    f"Hora de entrada: {hora_entrada}\n"
                    f"Tiempo restante: {horas_restantes} horas y {minutos_restantes} minutos."
                )
            else:
                # Cumple con las 8 horas, permitir registrar la salida
                messagebox.showinfo("Listo para Salida", f"Has cumplido con las 8 horas.\n\nHora de entrada: {hora_entrada}\nPuedes proceder a registrar tu salida.")
                btn_tomar_foto.pack(pady=10)  # Mostrar el botón para tomar foto
        else:
            # No tiene entrada registrada hoy, permitir registrar la entrada
            messagebox.showinfo("Bienvenido", f"Bienvenido, {nombre}\nPor favor, registra tu entrada.")
            btn_tomar_foto.pack(pady=10)  # Mostrar el botón para tomar foto
    finally:
        cursor.close()
        conexion.close()

# Función para iniciar la cámara
def iniciar_camara():
    global cap
    cap = cv2.VideoCapture(0)
    mostrar_captura()

# Mostrar el video en tiempo real
def mostrar_captura():
    global frame
    ret, frame = cap.read()
    if ret:
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        img = Image.fromarray(frame_rgb)
        imgtk = ImageTk.PhotoImage(image=img)
        lbl_video.imgtk = imgtk
        lbl_video.configure(image=imgtk)
        lbl_video.after(10, mostrar_captura)

# Guardar foto y registrar entrada/salida
def guardar_datos():
    capturar_foto(biometric_id)
    registrar_entrada_salida(biometric_id)
    cap.release()
    cv2.destroyAllWindows()
    lbl_video.configure(image='')

# Función para capturar y guardar foto
def capturar_foto(biometric_id):
    global frame
    if frame is None:
        messagebox.showerror("Error", "No se pudo capturar la foto.")
        return
    
    conexion = conectar_base_datos()
    if conexion is None:
        return

    _, buffer = cv2.imencode('.jpg', frame)
    imagen_binaria = buffer.tobytes()

    try:
        cursor = conexion.cursor()
        cursor.execute("INSERT INTO foto (biometric_id, imagen) VALUES (%s, %s)", (biometric_id, imagen_binaria))
        conexion.commit()
        messagebox.showinfo("Foto registrada", "Foto tomada y registrada exitosamente.")
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"No se pudo insertar la foto en la base de datos:\n{err}")
    finally:
        cursor.close()
        conexion.close()

# Función para registrar entrada o salida automáticamente
def registrar_entrada_salida(biometric_id):
    conexion = conectar_base_datos()
    if conexion is None:
        return

    try:
        cursor = conexion.cursor()
        
        # Obtener la última entrada del usuario
        cursor.execute("SELECT id, fecha_entrada, hora_entrada FROM entrada WHERE biometric_id = %s ORDER BY fecha_entrada DESC, hora_entrada DESC LIMIT 1", (biometric_id,))
        entrada = cursor.fetchone()

        if entrada:
            entrada_id, fecha_entrada, hora_entrada = entrada
            
            # Asegurarse de que hora_entrada sea del tipo correcto
            if isinstance(hora_entrada, timedelta):
                # Convertir timedelta a time si es necesario
                hora_entrada = (datetime.min + hora_entrada).time()
            
            # Combinar la fecha y la hora de entrada para calcular el tiempo transcurrido
            fecha_hora_entrada = datetime.combine(fecha_entrada, hora_entrada)
            tiempo_transcurrido = datetime.now() - fecha_hora_entrada
            
            if tiempo_transcurrido >= timedelta(hours=8):
                # Registrar la salida si se ha cumplido la jornada de 8 horas
                hora_salida = datetime.now()
                cursor.execute("INSERT INTO salida (biometric_id, fecha_salida, hora_salida, entrada_id) VALUES (%s, %s, %s, %s)",
                               (biometric_id, hora_salida.date(), hora_salida.time(), entrada_id))
                messagebox.showinfo("Salida registrada", "Salida registrada exitosamente.")
            else:
                # Calcular el tiempo restante y mostrar un mensaje si aún no se ha cumplido la jornada de 8 horas
                tiempo_restante = timedelta(hours=8) - tiempo_transcurrido
                horas_restantes = tiempo_restante.seconds // 3600
                minutos_restantes = (tiempo_restante.seconds % 3600) // 60
                messagebox.showwarning(
                    "Horario Incompleto",
                    f"No se puede marcar la salida hasta cumplir con el horario laboral de 8 horas.\n\n"
                    f"Tiempo restante: {horas_restantes} horas y {minutos_restantes} minutos."
                )
                return
        else:
            # Si no hay entrada previa, registrar una nueva entrada
            hora_entrada = datetime.now()
            cursor.execute("INSERT INTO entrada (biometric_id, fecha_entrada, hora_entrada) VALUES (%s, %s, %s)",
                           (biometric_id, hora_entrada.date(), hora_entrada.time()))
            messagebox.showinfo("Entrada registrada", "Entrada registrada exitosamente.")
        
        conexion.commit()
    except mysql.connector.Error as err:
        messagebox.showerror("Error", f"No se pudo registrar la entrada/salida:\n{err}")
    finally:
        cursor.close()
        conexion.close()


# Configuración de la ventana principal
ventana = tk.Tk()
ventana.title("Sistema de Bienvenida")
ventana.geometry("800x600")
ventana.configure(bg="#f0f2f5")

# Crear el menú
menu_bar = tk.Menu(ventana)
ventana.config(menu=menu_bar)

# Menú principal
menu_inicio = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Inicio", menu=menu_inicio)
menu_inicio.add_command(label="Inicio", command=lambda: messagebox.showinfo("Inicio", "Bienvenido al sistema de marcación"))

# Menú de exportación
menu_exportacion = tk.Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="Exportación", menu=menu_exportacion)
menu_exportacion.add_command(label="Exportar datos", command=exportacion.exportar_datos)

# Contenedor central
contenedor = tk.Frame(ventana, bg="#ffffff", relief="raised", bd=2, padx=20, pady=20)
contenedor.place(relx=0.5, rely=0.5, anchor="center")

# Etiqueta de título
label_titulo = tk.Label(contenedor, text="Sistema de Marcación", font=("Helvetica", 16, "bold"), bg="#ffffff", fg="#333333")
label_titulo.pack(pady=(0, 10))

# Entrada de cédula
label_cedula = tk.Label(contenedor, text="Ingrese su cédula:", font=("Helvetica", 12), bg="#ffffff")
label_cedula.pack()
entry_cedula = tk.Entry(contenedor, font=("Helvetica", 12), width=25)
entry_cedula.pack()

# Botón de búsqueda
btn_buscar = tk.Button(contenedor, text="Buscar Usuario", command=buscar_usuario, font=("Helvetica", 12), bg="#4CAF50", fg="#ffffff", width=15)
btn_buscar.pack(pady=(20, 10))

# Botón para tomar foto y registrar entrada/salida
btn_tomar_foto = tk.Button(contenedor, text="Tomar Foto", command=iniciar_camara, font=("Helvetica", 12), bg="#2196F3", fg="#ffffff", width=15)

# Etiqueta para mostrar el video en tiempo real
lbl_video = tk.Label(contenedor, bg="#ffffff")
lbl_video.pack(pady=10)

# Botón para capturar la foto y guardar los datos
btn_capturar = tk.Button(contenedor, text="Capturar y Guardar", command=guardar_datos, font=("Helvetica", 12), bg="#FF5722", fg="#ffffff", width=20)
btn_capturar.pack(pady=10)

ventana.mainloop()
